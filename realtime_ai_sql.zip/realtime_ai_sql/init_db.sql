-- Init DB for realtime-ai-sql
CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  description TEXT
);

INSERT INTO products (name, price, description) VALUES
('Laptop', 1200, '15-inch laptop, 16GB RAM'),
('Phone', 800, '5.8-inch smartphone'),
('Tablet', 400, '10-inch tablet')
ON CONFLICT DO NOTHING;
