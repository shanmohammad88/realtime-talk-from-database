/**
 * Realtime AI assistant (quick path)
 * - WebSocket backend that accepts user transcript text from client
 * - Performs SQL lookup (Postgres) when needed
 * - Calls OpenAI Responses API and returns AI reply to client
 *
 * Requirements:
 *  - Node 18+
 *  - npm install
 *  - set .env (see .env.example)
 *
 * Start:
 *  node server.js
 */
import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import pkg from "pg";
import fetch from "node-fetch";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const { Pool } = pkg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const WS_PATH = process.env.WS_PATH || "/ws";

app.use(express.static(path.join(__dirname, "public")));

app.get("/health", (req, res) => res.send("ok"));

const server = http.createServer(app);

// Attach WebSocket server to the same HTTP server
const wss = new WebSocketServer({ server, path: WS_PATH });
console.log(`WebSocket server running on ws://localhost:${PORT}${WS_PATH}`);

wss.on("connection", (ws) => {
  console.log("Client connected");

  ws.on("message", async (raw) => {
    try {
      const data = JSON.parse(raw);

      if (data.type === "user_message") {
        const userText = data.text;
        console.log("User:", userText);

        // Simple heuristic to detect DB lookup need
        let dbNote = null;
        const txtLower = userText.toLowerCase();

        if (txtLower.includes("price") || txtLower.includes("price of")) {
          // crude product extraction: last word (remove punctuation)
          const cleaned = userText.replace(/[?!.]/g, "").trim();
          const words = cleaned.split(/\s+/);
          const candidate = words[words.length - 1];

          // Parameterized query to avoid injection
          const result = await pool.query(
            "SELECT name, price, description FROM products WHERE LOWER(name) = LOWER($1) LIMIT 1",
            [candidate]
          );

          if (result.rows.length > 0) {
            const row = result.rows[0];
            dbNote = `DB_RESULT: Product ${row.name} — price $${row.price}. ${row.description || ""}`;
          } else {
            dbNote = `DB_RESULT: No product named '${candidate}' found.`;
          }
        }

        // Prepare prompt for OpenAI: inject DB result if present
        const prompt = dbNote
          ? `${dbNote}\n\nUser asked: ${userText}\nPlease answer based on the DB_RESULT when appropriate.`
          : userText;

        // Call OpenAI Responses API (text)
        const resp = await fetch("https://api.openai.com/v1/responses", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
            input: prompt,
            // you can set temperature, max_output_tokens, etc. here
          }),
        });

        if (!resp.ok) {
          const txt = await resp.text();
          console.error("OpenAI API error:", resp.status, txt);
          ws.send(JSON.stringify({ type: "error", message: "OpenAI API error: " + resp.status }));
          return;
        }

        const ai = await resp.json();
        // Responses API may return array outputs; try common shapes
        const reply =
          ai.output?.[0]?.content?.[0]?.text ??
          ai.output_text ??
          ai?.text ??
          "Sorry, I couldn't generate a reply.";

        // Send reply back to client
        ws.send(JSON.stringify({ type: "ai_reply", text: reply }));
      }
    } catch (err) {
      console.error("Error handling message:", err);
      try { ws.send(JSON.stringify({ type: "error", message: err.message })); } catch(e){/* ignore */ }
    }
  });

  ws.on("close", () => console.log("Client disconnected"));
});

server.listen(PORT, () => {
  console.log(`HTTP server listening on http://localhost:${PORT}`);
  console.log("Open http://localhost:" + PORT + " in your browser to open the client UI (public/index.html).");
});
