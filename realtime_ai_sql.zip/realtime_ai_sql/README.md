# Realtime AI Assistant (Quick Path) — ZIP package

## What this provides
- `server.js` : Node.js Express + WebSocket backend that:
  - Accepts transcript text from client
  - Performs simple SQL lookup (Postgres) for product prices (heuristic)
  - Calls OpenAI Responses API and returns text reply
- `public/index.html` : simple browser client using SpeechRecognition & SpeechSynthesis
- `init_db.sql` : SQL to create `products` table and sample rows
- `.env.example` : example environment variables
- `package.json` : npm config

## Steps to run (Postgres)
1. Install dependencies:
   ```bash
   npm install
   ```
2. Create a Postgres database and run the SQL in `init_db.sql`:
   ```bash
   psql "postgres://dbuser:dbpass@localhost:5432/mydb" -f init_db.sql
   ```
   Replace connection string as appropriate.
3. Copy `.env.example` to `.env` and fill in:
   ```
   cp .env.example .env
   # edit .env and set OPENAI_API_KEY and DATABASE_URL
   ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open your browser at `http://localhost:3000` and click Start. Ask:
   `What's the price of Laptop?`

## Notes
- This project uses browser STT/TTS for simplicity. For production-grade low-latency voice streaming, see OpenAI Realtime (WebRTC) docs and follow ephemeral token flow.
- Do NOT put your permanent OpenAI API key into client-side code. Keep it in server `.env`.
- The product detection uses a crude heuristic (last word). For better results, integrate a small NLU step or function-calling to extract entities reliably.

## Troubleshooting
- If the browser doesn't support SpeechRecognition, use Chrome or Edge.
- If OpenAI Responses API returns errors, check your API key and model name.
